import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { QuoteFormComponent } from './components/quote-form/quote-form.component';
import { QuotePreviewComponent } from './components/quote-preview/quote-preview.component';
import { Quote } from './models/quote.model';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [CommonModule, QuoteFormComponent, QuotePreviewComponent],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css',
})
export class AppComponent {
  title = 'devis-generateur';
  currentQuote: Quote | null = null;

  onQuoteUpdated(quote: Quote) {
    this.currentQuote = quote;
  }
}
