import { Component, computed, signal, WritableSignal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { QuoteFormComponent } from './components/quote-form/quote-form.component';
import { QuotePreviewComponent } from './components/quote-preview/quote-preview.component';
import { Quote } from './models/quote.model';
const ENCRYPTED_PASSWORD = 'a24yMDIx';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [CommonModule, QuoteFormComponent, QuotePreviewComponent],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css',
})
export class AppComponent {
  title = 'devis-generateur';

  currentQuote: Quote | null = null;
  // Signal to manage authentication state
  isLoggedIn: WritableSignal<boolean> = signal(false);

  // Signal to manage error state in the UI
  passwordAttemptFailed: WritableSignal<boolean> = signal(false);

  // Computed signal for UI error visibility (debounce is often used here, omitted for simplicity)
  showError = computed(() => this.passwordAttemptFailed());

  // Store the accepted password, decoded from Base64
  private acceptedPassword: string = atob(ENCRYPTED_PASSWORD);
  onQuoteUpdated(quote: Quote) {
    this.currentQuote = quote;
  }
  /**
   * Checks the user's input against the decoded password.
   * @param inputPassword The password entered by the user.
   */
  checkPassword(inputPassword: string): void {
    if (inputPassword === this.acceptedPassword) {
      this.isLoggedIn.set(true); // Grant access
      this.passwordAttemptFailed.set(false);
    } else {
      this.passwordAttemptFailed.set(true); // Show error message
    }
  }
  resetError(): void {
    this.passwordAttemptFailed.set(false);
  }
}
