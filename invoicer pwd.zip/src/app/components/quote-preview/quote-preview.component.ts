import { Component, Input } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Quote } from '../../models/quote.model';
import html2canvas from 'html2canvas';
import jsPDF from 'jspdf';

@Component({
  selector: 'app-quote-preview',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './quote-preview.component.html',
  styleUrl: './quote-preview.component.css'
})
export class QuotePreviewComponent {
  @Input() quote!: Quote;

  generatePDF() {
    const element = document.getElementById('quote-preview');
    if (element) {
      // Configure html2canvas options for better quality
      const options = {
        scale: 2,
        useCORS: true,
        allowTaint: true,
        backgroundColor: '#ffffff',
        width: element.scrollWidth,
        height: element.scrollHeight
      };

      html2canvas(element, options).then(canvas => {
        const imgData = canvas.toDataURL('image/png');
        const pdf = new jsPDF('p', 'mm', 'a4');
        
        // Calculate dimensions
        const imgWidth = 210; // A4 width in mm
        const pageHeight = 295; // A4 height in mm
        const imgHeight = (canvas.height * imgWidth) / canvas.width;
        let heightLeft = imgHeight;
        let position = 0;

        // Add first page
        pdf.addImage(imgData, 'PNG', 0, position, imgWidth, imgHeight);
        heightLeft -= pageHeight;

        // Add additional pages if needed
        while (heightLeft >= 0) {
          position = heightLeft - imgHeight;
          pdf.addPage();
          pdf.addImage(imgData, 'PNG', 0, position, imgWidth, imgHeight);
          heightLeft -= pageHeight;
        }

        // Download the PDF
        const filename = `Devis_${this.quote.header.quoteNumber || 'DRAFT'}_${this.quote.header.clientName || 'Client'}.pdf`;
        pdf.save(filename);
      }).catch(error => {
        console.error('Erreur lors de la génération du PDF:', error);
        alert('Une erreur est survenue lors de la génération du PDF. Veuillez réessayer.');
      });
    }
  }

  printQuote() {
    window.print();
  }

  getCurrentDate(): string {
    return new Date().toLocaleDateString('fr-FR');
  }

  getValidityDate(): string {
    const date = new Date();
    date.setMonth(date.getMonth() + 1); // Valid for 1 month
    return date.toLocaleDateString('fr-FR');
  }

  formatAddress(address: string): string {
    return address ? address.replace(/\n/g, '<br>') : '';
  }
}
