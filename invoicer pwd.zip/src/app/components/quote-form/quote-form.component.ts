import { Component, Output, EventEmitter } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import {
  Quote,
  Category,
  QuoteService,
  AVAILABLE_SERVICES,
  TVA_RATE,
} from '../../models/quote.model';

@Component({
  selector: 'app-quote-form',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './quote-form.component.html',
  styleUrl: './quote-form.component.css',
})
export class QuoteFormComponent {
  @Output() quoteUpdated = new EventEmitter<Quote>();

  quote: Quote = {
    header: {
      quoteNumber: 'DEV-2024-001',
      date: new Date(),
      validityPeriod: 30,
      clientName: '',
      clientAddress: '',
      clientEmail: '',
      phone: '+33 1 23 45 67 89',
      email: 'contact@lafinition.fr',
    },
    categories: [],
    totals: {
      subtotal: 0,
      tax: 0,
      total: 0,
      taxRate: TVA_RATE,
    },
  };

  availableServices = AVAILABLE_SERVICES;

  constructor() {
    this.addCategory();
  }

  addCategory(): void {
    const newCategory: Category = {
      id: Date.now(),
      name: 'Nouvelle catégorie',
      services: [],
    };
    this.quote.categories.push(newCategory);
    this.updateTotals();
  }

  addService(categoryId: number): void {
    const category = this.quote.categories.find((cat) => cat.id === categoryId);
    if (category) {
      const newService: QuoteService = {
        id: Date.now(),
        description: this.availableServices[0].name,
        quantity: 1,
        unit: 'h',
        unitPrice: 0,
      };
      category.services.push(newService);
      this.updateTotals();
    }
  }

  updateTotals(): void {
    let subtotal = 0;

    this.quote.categories.forEach((category) => {
      category.services.forEach((service) => {
        subtotal += service.quantity * service.unitPrice;
      });
    });

    const tax = subtotal * TVA_RATE;
    const total = subtotal + tax;

    this.quote.totals = {
      subtotal,
      tax,
      total,
      taxRate: TVA_RATE,
    };

    this.quoteUpdated.emit(this.quote);
  }

  removeCategory(categoryId: number): void {
    this.quote.categories = this.quote.categories.filter(
      (cat) => cat.id !== categoryId
    );
    this.updateTotals();
  }

  removeService(categoryId: number, serviceId: number): void {
    const category = this.quote.categories.find((cat) => cat.id === categoryId);
    if (category) {
      category.services = category.services.filter((s) => s.id !== serviceId);
      this.updateTotals();
    }
  }
}
