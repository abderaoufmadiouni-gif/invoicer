export interface Quote {
  header: {
    quoteNumber: string;
    date: Date;
    validityPeriod: number;
    clientName: string;
    clientAddress: string;
    clientEmail: string;
    phone: string;
    email: string;
  };
  categories: Category[];
  totals: {
    subtotal: number;
    tax: number;
    total: number;
    taxRate: number;
  };
}

export interface Category {
  id: number;
  name: string;
  services: QuoteService[];
}

export interface QuoteService {
  id: number;
  description: string;
  quantity: number;
  unit: string;
  unitPrice: number;
}

export const AVAILABLE_SERVICES = [
  { id: 1, name: 'Enduit complémentaire de garnissage' },
  { id: 2, name: 'Application couche primaire anti moisissure' },
  { id: 3, name: 'Finition 2 couches peintures' },
  { id: 4, name: 'Enduit complémentaire de garnissage' },
  { id: 5, name: 'Application couche primaire anti moisissure' },
];

export const TVA_RATE = 0.1;
